TEST_PHP_EXECUTABLE=`which php` php -dxdebug.auto_trace=0 run-tests.php ${TESTS}
